this["RQ"] = this["RQ"] || {};
this["RQ"]["Templates"] = this["RQ"]["Templates"] || {};

this["RQ"]["Templates"]["DevtoolsPage"] = Handlebars.template({"compiler":[8,">= 4.3.0"],"main":function(container,depth0,helpers,partials,data) {
    return "<div class=\"toolbar\">\n  <div class=\"toolbar-item\">\n    <button type=\"button\" class=\"clear-logs\">&#128683; Clear</button>\n  </div>\n\n  <div class=\"toolbar-item\">\n    <label for=\"url-filter\">Request URL:</label>\n    <input type=\"text\" id=\"url-filter\" placeholder=\"Filter\">\n  </div>\n\n  <div class=\"toolbar-item\">\n    <label for=\"rule-filter\">Rule:</label>\n    <input type=\"text\" id=\"rule-filter\" placeholder=\"Filter\">\n  </div>\n</div>\n<table>\n  <thead>\n    <tr>\n      <th class=\"cell-time\">Time</th>\n      <th class=\"cell-url\">Request URL</th>\n      <th class=\"cell-method\">Method</th>\n      <th class=\"cell-type\">Type</th>\n      <th class=\"cell-rule-name\">Rule</th>\n      <th class=\"cell-modification\">Modification</th>\n    </tr>\n  </thead>\n  <tbody id=\"rows\" />\n</table>";
},"useData":true});

this["RQ"]["Templates"]["Row"] = Handlebars.template({"1":function(container,depth0,helpers,partials,data) {
    var helper, lookupProperty = container.lookupProperty || function(parent, propertyName) {
        if (Object.prototype.hasOwnProperty.call(parent, propertyName)) {
          return parent[propertyName];
        }
        return undefined
    };

  return container.escapeExpression(((helper = (helper = lookupProperty(helpers,"requestMethod") || (depth0 != null ? lookupProperty(depth0,"requestMethod") : depth0)) != null ? helper : container.hooks.helperMissing),(typeof helper === "function" ? helper.call(depth0 != null ? depth0 : (container.nullContext || {}),{"name":"requestMethod","hash":{},"data":data,"loc":{"start":{"line":4,"column":47},"end":{"line":4,"column":64}}}) : helper)));
},"3":function(container,depth0,helpers,partials,data) {
    return "-";
},"5":function(container,depth0,helpers,partials,data) {
    var lookupProperty = container.lookupProperty || function(parent, propertyName) {
        if (Object.prototype.hasOwnProperty.call(parent, propertyName)) {
          return parent[propertyName];
        }
        return undefined
    };

  return container.escapeExpression((lookupProperty(helpers,"parseRequestType")||(depth0 && lookupProperty(depth0,"parseRequestType"))||container.hooks.helperMissing).call(depth0 != null ? depth0 : (container.nullContext || {}),(depth0 != null ? lookupProperty(depth0,"requestType") : depth0),{"name":"parseRequestType","hash":{},"data":data,"loc":{"start":{"line":5,"column":43},"end":{"line":5,"column":75}}}));
},"compiler":[8,">= 4.3.0"],"main":function(container,depth0,helpers,partials,data) {
    var stack1, helper, alias1=depth0 != null ? depth0 : (container.nullContext || {}), alias2=container.hooks.helperMissing, alias3="function", alias4=container.escapeExpression, lookupProperty = container.lookupProperty || function(parent, propertyName) {
        if (Object.prototype.hasOwnProperty.call(parent, propertyName)) {
          return parent[propertyName];
        }
        return undefined
    };

  return "<tr>\n  <td class=\"cell-time\">"
    + alias4(((helper = (helper = lookupProperty(helpers,"time") || (depth0 != null ? lookupProperty(depth0,"time") : depth0)) != null ? helper : alias2),(typeof helper === alias3 ? helper.call(alias1,{"name":"time","hash":{},"data":data,"loc":{"start":{"line":2,"column":24},"end":{"line":2,"column":32}}}) : helper)))
    + "s</td>\n  <td class=\"cell-url\">"
    + alias4(((helper = (helper = lookupProperty(helpers,"requestURL") || (depth0 != null ? lookupProperty(depth0,"requestURL") : depth0)) != null ? helper : alias2),(typeof helper === alias3 ? helper.call(alias1,{"name":"requestURL","hash":{},"data":data,"loc":{"start":{"line":3,"column":23},"end":{"line":3,"column":37}}}) : helper)))
    + "</td>\n  <td class=\"cell-method\">"
    + ((stack1 = lookupProperty(helpers,"if").call(alias1,(depth0 != null ? lookupProperty(depth0,"requestMethod") : depth0),{"name":"if","hash":{},"fn":container.program(1, data, 0),"inverse":container.program(3, data, 0),"data":data,"loc":{"start":{"line":4,"column":26},"end":{"line":4,"column":80}}})) != null ? stack1 : "")
    + "</td>\n  <td class=\"cell-type\">"
    + ((stack1 = lookupProperty(helpers,"if").call(alias1,(depth0 != null ? lookupProperty(depth0,"requestType") : depth0),{"name":"if","hash":{},"fn":container.program(5, data, 0),"inverse":container.program(3, data, 0),"data":data,"loc":{"start":{"line":5,"column":24},"end":{"line":5,"column":91}}})) != null ? stack1 : "")
    + "</td>\n  <td class=\"cell-rule-name\"><a href=\""
    + alias4(((helper = (helper = lookupProperty(helpers,"ruleLink") || (depth0 != null ? lookupProperty(depth0,"ruleLink") : depth0)) != null ? helper : alias2),(typeof helper === alias3 ? helper.call(alias1,{"name":"ruleLink","hash":{},"data":data,"loc":{"start":{"line":6,"column":38},"end":{"line":6,"column":50}}}) : helper)))
    + "\" target=\"_blank\" title=\"Open in new tab\">"
    + alias4(container.lambda(((stack1 = (depth0 != null ? lookupProperty(depth0,"rule") : depth0)) != null ? lookupProperty(stack1,"name") : stack1), depth0))
    + "</a></td>\n  <td class=\"cell-modification\">"
    + alias4(((helper = (helper = lookupProperty(helpers,"modification") || (depth0 != null ? lookupProperty(depth0,"modification") : depth0)) != null ? helper : alias2),(typeof helper === alias3 ? helper.call(alias1,{"name":"modification","hash":{},"data":data,"loc":{"start":{"line":7,"column":32},"end":{"line":7,"column":48}}}) : helper)))
    + "</td>\n</tr>\n";
},"useData":true});